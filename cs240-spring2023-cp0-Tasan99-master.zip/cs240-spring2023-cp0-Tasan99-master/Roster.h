#include<stdlib.h>

using namespace std;

class Roster{
 public:
   Roster( int student);

   Roster();
  

 private:
   int numberofstudents;

};
   
