#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <vector>

using namespace std;


int main()
{
  while(true){
  string line;
  cout<<"enter:";
  getline(cin,line); 
  istringstream iss(line); 
  vector<string> words(istream_iterator<string>(iss),istream_iterator<string>{}); 
  if(words[0]=="build"){
    cout<<"Build "<<"Course "<<words[1]<<" "<<words[2]<<" "<<words[3]<<" "<<words[4] <<endl;
    words.clear();  
  }
  else if(words[0]=="cancel"){
    cout<<"Cancel "<<"Course "<<words[1]<<endl;
    words.clear();
  }
  else if(words[0]=="enroll"){
    cout<<"enroll "<<"student "<<words[1]<<" "<<words[2]<<" "<<words[3]<<","<<words[4] <<endl;
    words.clear();
  }
  else if(words[0]=="add"){
    cout<<"add "<<"student "<<words[1]<<"into course "<<words[2]<<endl;
    words.clear();
  }
  else if(words[0]=="drop"){
    cout<<"remove "<<"student "<<words[1]<<"from course "<<words[2]<<endl;
    words.clear();
  }
  else if(words[0]=="roster"){
    cout<<"roster of course sample "<<words[1]<<endl;
    words.clear();
  }
    
  else if(words[0]=="schedule"){
    cout<<"schedule of student "<<words[1]<<endl;
    words.clear();
  }
  else if(words[0]=="quit"){
            break;
    }
  else{
    cout<<"Command not recognized, please try again."<<endl;
    continue;
  }
    }
  
    
  return 0;
}

