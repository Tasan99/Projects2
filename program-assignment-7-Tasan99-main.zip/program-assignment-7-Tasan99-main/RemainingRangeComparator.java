class RemainingRangeComparator implements java.util.Comparator<CarFunctions>
{
	public int compare(CarFunctions o1, CarFunctions o2)
	{
		return 0;
	}
}
