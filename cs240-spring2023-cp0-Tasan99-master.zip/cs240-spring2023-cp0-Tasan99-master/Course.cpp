#include <iostream>
#include <stdlib.h>
#include "Course.h"

using namespace std;
Course :: Course(string name, unsigned int capacity, string instruct ) {
  courseName = name;
  maximumCapacity = capacity;
  instructor = instruct;
  students=Roster(100);
  }


Course :: Course() {
  courseName = "";
  maximumCapacity = 0;
  instructor = "";
  students=Roster();
  }
  

void Course :: show() {
  cout << courseName << " (" << maximumCapacity << "): " << instructor << endl;
  }

