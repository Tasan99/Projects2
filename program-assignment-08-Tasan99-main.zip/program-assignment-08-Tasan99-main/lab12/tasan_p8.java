class tasan_p8
{
    private static int width = 700;
    private static int height = 350;
    private static int width2 =330;



    public static void main(String[] args)
    {
        // create the window and specify the size and what to do when the window is closed
        javax.swing.JFrame f = new javax.swing.JFrame();
        f.setPreferredSize(new java.awt.Dimension(width, height));
        f.setMinimumSize(new java.awt.Dimension(width, height));
        f.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);

        // create the menu bar
        javax.swing.JMenuBar menuBar = new javax.swing.JMenuBar();

        // create the two menus
        javax.swing.JMenu fileMenu = new javax.swing.JMenu("File");

        // create the menu items for the two menus
        javax.swing.JMenuItem fileExit = new javax.swing.JMenuItem("Exit");
        javax.swing.JMenuItem Read_sort_file = new javax.swing.JMenuItem("Read sort file");
        javax.swing.JMenuItem Read_search_file  = new javax.swing.JMenuItem("Read search file");

        MenuItemActionListener fileExitMenuItemActionListener = new MenuItemActionListener(fileExit);
        MenuItemActionListener fileReadSortFileMenuItemListener = new MenuItemActionListener(Read_sort_file);
        MenuItemActionListener fileReadSearchFileMenuItemListener = new MenuItemActionListener(Read_search_file);



        fileExit.addActionListener(fileExitMenuItemActionListener);
        fileExit.addActionListener(fileReadSortFileMenuItemListener);
        fileExit.addActionListener(fileReadSearchFileMenuItemListener);




        // add the two menus to the menu bar
        menuBar.add(fileMenu);

        // add the two menu items to the two menus
        fileMenu.add(fileExit);
        fileMenu.add(Read_sort_file);
        fileMenu.add(Read_search_file);

        javax.swing.JPanel leftButtonPanel = new javax.swing.JPanel();
        leftButtonPanel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0, 255), 2));
        java.awt.GridBagLayout leftButtonPanelGridBagLayout = new java.awt.GridBagLayout();
        leftButtonPanel.setLayout(leftButtonPanelGridBagLayout);
        java.awt.GridBagConstraints leftButtonPanelConstraints = new java.awt.GridBagConstraints();

        javax.swing.JPanel rightButtonPanel = new javax.swing.JPanel();
        rightButtonPanel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0, 255), 2));
        java.awt.GridBagLayout rightButtonPanelGridBagLayout = new java.awt.GridBagLayout();
        rightButtonPanel.setLayout(rightButtonPanelGridBagLayout);

        javax.swing.JPanel mainButtonPanel = new javax.swing.JPanel();
        mainButtonPanel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0, 255), 2));
        javax.swing.BoxLayout mainButtonBoxLayout = new javax.swing.BoxLayout(mainButtonPanel, javax.swing.BoxLayout.X_AXIS);
        mainButtonPanel.setLayout(mainButtonBoxLayout);
        mainButtonPanel.add(leftButtonPanel);
        mainButtonPanel.add(rightButtonPanel);

        javax.swing.JPanel mainPanel = new javax.swing.JPanel();
        mainPanel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0, 255), 2));
        mainPanel.setLayout(new java.awt.BorderLayout());
        mainPanel.add(menuBar, java.awt.BorderLayout.NORTH);
        mainPanel.add(mainButtonPanel, java.awt.BorderLayout.CENTER);

        leftButtonPanel.setPreferredSize(new java.awt.Dimension(width2, height));
        leftButtonPanel.setMinimumSize(new java.awt.Dimension(width2, height));
        rightButtonPanel.setPreferredSize(new java.awt.Dimension(width2, height));
        rightButtonPanel.setMinimumSize(new java.awt.Dimension(width2,height));

        f.setContentPane(mainPanel);
        f.validate();
        f.setVisible(true);
    }

    // action listener for the buttons
    static class ButtonActionListener implements java.awt.event.ActionListener
    {
        // the button associated with the action listener, so that we can
        // share this one class with multiple buttons
        private javax.swing.JButton b;

        ButtonActionListener(javax.swing.JButton b)
        {
            this.b = b;
        }

        public void actionPerformed(java.awt.event.ActionEvent e)
        {
            System.out.println("action performed on " + b.getText() + " button");
        }
    }

    // action listener for the menu items
    static class MenuItemActionListener implements java.awt.event.ActionListener
    {
        // the menu item associated with the action listener, so that we can
        // share this one class with multiple menu items
        private javax.swing.JMenuItem m;

        MenuItemActionListener(javax.swing.JMenuItem m)
        {
            this.m = m;
        }

        public void actionPerformed(java.awt.event.ActionEvent e)
        {
            System.out.println("action performed on " + m.getText() + " menu item");

            // if exit is selected from the file menu, exit the program
            if( m.getText().toLowerCase().equals("exit") )
            {
                System.exit(0);
            }

            // if color is selected from the edit menu, put a popup on the screen
            // saying something
            if( m.getText().toLowerCase().equals("color") )
            {
                Object[] options = {"OK"};
                javax.swing.JOptionPane.showOptionDialog(null, "This is unimplemented,\nclick OK to continue",
                        "Warning", javax.swing.JOptionPane.DEFAULT_OPTION,
                        javax.swing.JOptionPane.WARNING_MESSAGE, null, options, options[0]);
            }
        }
    }
}