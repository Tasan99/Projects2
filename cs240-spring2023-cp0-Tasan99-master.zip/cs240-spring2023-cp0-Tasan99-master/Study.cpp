#include <iostream>
#include <stdlib.h>
#include "Course.h"
using namespace std;

int main(int argc, char *argv[]) {
   Course one;
   Course *two = new Course("CS 240", 100, "emir");
   Course *three =new Course("CS 340", 500, "Teoman");
   Course four;
   
   one.show();
   two->show();
   three->show();
   four.show();
   delete(two);
   delete(three);
}
