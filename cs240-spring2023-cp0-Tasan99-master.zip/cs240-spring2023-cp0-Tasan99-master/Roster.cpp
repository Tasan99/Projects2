#include<stdlib.h>
#include"Roster.h"

Roster::Roster( int students){
  numberofstudents=students;
}
Roster::Roster(){
  numberofstudents=0;
}
 
  
